#ifndef Int_xxx
#define INt_xxx

typedef int Elemtype;
//声明一个结构体来表示节点
typedef struct Node
{
     Elemtype data;   //节点数据域
     struct Node * next; //节点指针域
}QueueNode;
//声明一个结构体来定义上面这个结构体的两个指针
typedef struct
{
    QueueNode *front,*rear;//分别指向队首和队尾的指针
}LinkQueue;

void Init(LinkQueue *s);
int Empty(LinkQueue s);
int GetLength(LinkQueue s);
void Add(LinkQueue *s,Elemtype x);
Elemtype GetTop(LinkQueue s);
void Del(LinkQueue *s,Elemtype *e);
void StackTraverse(LinkQueue *s);
void Delete(LinkQueue *s);
#endif