#include "public.h"


void initcounter()
{
	TMOD=0x06;  //0000 0110
	TH0=256-3;
	TL0=256-3;
	ET0=1;
	EA=1;
	TR0=1;
}

void display()
{
	P2=s[num];
	if(num==10)
	{
		num=0;
	}
}

void counter_isr()  interrupt  1
{
	num++;
}