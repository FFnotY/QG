#ifndef _public_H
#define _public_H

#include"reg51.h"

void initcounter();
void display();

#endif