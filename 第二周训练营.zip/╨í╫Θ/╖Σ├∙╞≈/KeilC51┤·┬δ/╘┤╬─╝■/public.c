#include "public.h"


void delay(unsigned int i)
{
	while(i--);
}