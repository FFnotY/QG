#include"reg51.h"

sbit BEEP=P1^1;

void delay(unsigned int i)
{
	while(i--);
}

void main()
{
	while(1)
	{
		BEEP=1;
		delay(200);
		BEEP=0;
		delay(200);
	}
}