#ifndef _public_H
#define _public_H

#include"reg51.h"

sbit BEEP=P1^1;

void delay(unsigned int i);

#endif