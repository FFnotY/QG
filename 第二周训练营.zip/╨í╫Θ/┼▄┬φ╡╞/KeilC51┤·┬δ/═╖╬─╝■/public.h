#ifndef _public_H
#define _public_H

#include <REGX52.H>

void Delay1ms(unsigned int xms);	

#endif