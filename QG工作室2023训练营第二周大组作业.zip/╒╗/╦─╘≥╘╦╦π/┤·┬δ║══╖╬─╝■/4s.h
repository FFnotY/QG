#ifndef Int_xxx
#define INt_xxx

typedef struct node
{
    char data;
    struct node* next;
}StackNode;
typedef struct seqstack
{
    int size;
    StackNode* top;
}LinkStack;

LinkStack*  initstack();
int isempty(LinkStack* S);
StackNode* seqstack_top(LinkStack* S);
StackNode* Pop(LinkStack* S);
void Push(LinkStack* S,char x);
void char_put(char ch);
int priority(char ch);
int is_number(char ch);
int is_operator(char ch);
int is_left(char ch);
int is_right(char ch);
int transform(char str[]);


typedef struct node1
{
    int data;
    struct node1* next;
}StackNode1;
typedef struct seqstack1
{
    int size;
    StackNode1* top;
}LinkStack1;

LinkStack1*  initstack1();
int isempty1(LinkStack1* S);
int seqstack_top1(LinkStack1* S);
int Pop1(LinkStack1* S);
void Push1(LinkStack1* S,int x);
int express(int left,int right,char yunsuanfu);
int getsize(LinkStack1* stack);
int calculate(char str[]);

#endif