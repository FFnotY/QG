#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lianzhan.h"

//链式结构


//初始化链栈
void InitStack(LinkStack *S)
{
    S->top=-1;
    printf("初始化成功");
}


//判断链栈是否为空
bool Stackempty(LinkStack *S)
{
    if(S->top==-1)
        return true;
       
    else
        return false;
        
}

//链栈的入栈
bool Push(LinkStack *S, int e)
{
    StackNode *p=(StackNode *)malloc(sizeof(StackNode));
    p->data=e;
    p->next=S->top;
    S->top=p;   //修改栈顶指针
    printf("入栈成功");
    return true;
}


//链栈的出栈
bool Pop(LinkStack *S,int *e)
{
    StackNode *a=S->top;
    if(a==NULL)
        return false;
    StackNode *p=a;
    *e=a->data;
    S->top=a->next;
    free(p);
    S->count--;
    return true;
}

//链栈的遍历
void StackTraverse(LinkStack *S)
{
    LinkStackPtr p=S->top;
    
    printf("LinkStack");
    while(p!=NULL){
        printf("%d->",p->data);
        p=p->next;
    
    }
    
        
    printf("NULL\n");
}

