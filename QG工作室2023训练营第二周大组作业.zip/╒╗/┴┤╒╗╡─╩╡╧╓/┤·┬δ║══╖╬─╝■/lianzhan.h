#ifndef Int_xxx
#define INt_xxx


typedef struct StackNode
{
    int data;
    struct StackNode *next;
} StackNode,*LinkStackPtr;

typedef struct LinkStack
{
    LinkStackPtr top;  //栈顶指针
    int count;  //栈中的元素
}LinkStack;

void InitStack(LinkStack *S);
bool Stackempty(LinkStack *S);
bool Push(LinkStack *S, int e);
bool Pop(LinkStack *S,int *e);
void StackTraverse(LinkStack *S);
#endif