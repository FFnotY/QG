#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "danlianbiao.h"




//初始化一个单链表(带头结点) 
bool InitList(LinkList *L){
     L=(LNode*)malloc(sizeof(LNode));               //分配给头指针L一片空间作为头节点 
	if (L==NULL){                                  //判断头指针是否为空 
		return false;
	}
    L->next = NULL;                              //头节点之后暂时没有节点
	    return true; 
}

//插入新的节点(后插)
bool ListInsert(LinkList *L, int i, int e){
	if(i<1){                                        //判断i值是否合法 
		return false;
	}
	int j;
	LNode *p;
	p=L;                                            //p一开始指向头节点也就是第0个节点 
	j=0;                                            //用j来表示p当前指向的节点 
	while(p!=NULL && j<i-1){                        //寻找要插入的节点i的前一个节点 
		p=p->next;                                  //让p指针指向下一个节点 
		j++;
	}
	if (p==NULL){                                   //当要插入的节点超过了链表的范围，p 
		return false;                               //会指向空，即p==NULL 
	}
	LNode *s=(LNode*)malloc(sizeof(LNode));
	s->data =e;
	s->next =p->next;
	p->next =s;
	
} 
//删除节点
bool  Nodedelete(LinkList *L, int i){
	if(i<1){                                       
		return false;
	}
	int j;
	LNode *p;
	p=L;                                            
	j=0;                                            
	while(p!=NULL && j<i-1){                        
		p=p->next;                                  
		j++;
	}	

	 
	if(p==NULL) {                                 //当要删除节点的前置节点为空时 
		return false;
	}
	LNode *q=p->next;                             //让q指向被删除的节点 
	                                    
	p->next=q->next;                              //将q所指的要删除的节点断开
	free(q) ;
	return true;
} 

//查找链表
//按位查找
LNode *GetElem(LinkList *L, int i){
	if (i<0){
		return NULL;
	}
	LNode *p;
	int j=0;
	p=L;
	while(p!=NULL && j<=i){
		p=p->next;
		j++;
	}
	return p;
} 


 
 //尾插法建立单链表（指针） 
LinkList List_Taillnsert(LinkList *L,int i) {
	int x;
	LNode *a=(LNode*)malloc(sizeof(LNode));                     //建立头节点 

	LNode *s, *r=a;                                    //定义r为表尾指针
	scanf("%d",&x);                                    //输入节点的值  
	printf("x=%d",x);
	int m=1;
	int n=1;
    while(n<=i)
    {
		printf("第%d个节点的数据是",m);
        s=(LNode*)malloc(sizeof(LNode));
        s->data=x;
        r->next=s;
        r=s;
        scanf("%d",&x);
		m++;
    }
    r->next=NULL;
	 
    return *a;
}
//单链表的后删
bool DeleteNextNode(LNode *p)
{
	if(p==NULL) return false;
	LNode*q = p->next;               //找到p的后继节点
	if(q==NULL) return false;       //q没有后继
	p->next=q->next;
	free(q);                        //释放空间
	return true;
}
    
//显示链表
void displayLinkedList(LinkList* L) {
    LNode* current = L;
    printf("L: ");
    while (current != NULL) {
        printf("%d -> ", current->data);
        current = current->next;
    }
    printf("NULL\n");
}    

//链表的销毁 
void DestoryList(LinkList *L){
	while(L->next!=NULL){
		DeleteNextNode(&L); 
		free(L);
		L=NULL;
	}
}	

 
 
