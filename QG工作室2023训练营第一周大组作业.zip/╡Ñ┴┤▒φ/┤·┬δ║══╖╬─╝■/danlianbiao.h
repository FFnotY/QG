#ifndef Int_xxx
#define INt_xxx

typedef struct LNode{
	int data;                                  //节点存放的数据元素 
	struct LNode *next;                             //指向下一个节点的指针 
}LNode,LinkList;

bool InitList(LinkList *L);
bool ListInsert(LinkList *L, int i, int e);
bool  Nodedelete(LinkList *L, int i);
LNode *GetElem(LinkList *L, int i);
LinkList List_Taillnsert(LinkList *L,int i);
bool DeleteNextNode(LNode *p);
void displayLinkedList(LinkList* L);
void DestoryList(LinkList *L);



#endif